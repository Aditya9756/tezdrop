import 'product_model.dart';

class CartItemModel {
  final ProductModel product;
  int quantity;

  CartItemModel({required this.product, this.quantity = 1});

  double get totalPrice => product.price * quantity;

  Map<String, dynamic> toJson() => {
    'id'       : product.id,
    'name'     : product.name,
    'price'    : product.price,
    'qty'      : quantity,
    'isGrocery': product.isGrocery,
    'image'    : product.image,
  };
}
