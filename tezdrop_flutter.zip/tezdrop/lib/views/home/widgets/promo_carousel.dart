import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/routes/app_routes.dart';
import '../../../providers/app_state_provider.dart';

class PromoCarousel extends StatefulWidget {
  const PromoCarousel({super.key});
  @override
  State<PromoCarousel> createState() => _PromoCarouselState();
}

class _PromoCarouselState extends State<PromoCarousel> {
  int _current = 0;

  final List<_Promo> _promos = const [
    _Promo(
      grad: [Color(0xFF7C3AED), Color(0xFF4F46E5)],
      badge: 'Mega Sale',
      title: '50% OFF on\nFirst Order',
      sub: 'Use code: TEZDROP50',
      icon: Icons.lunch_dining,
      btnText: 'Grab Now',
      action: 'coupon:TEZDROP50',
    ),
    _Promo(
      grad: [Color(0xFF22C55E), Color(0xFF059669)],
      badge: '🛒 Grocery',
      title: 'Fresh Groceries\nDelivered',
      sub: 'Vegetables, dairy & more!',
      icon: Icons.shopping_basket,
      btnText: 'Shop Now',
      action: 'grocery',
    ),
    _Promo(
      grad: [Color(0xFFF97316), Color(0xFFEC4899)],
      badge: 'Rewards',
      title: 'Earn TezCoins\nDaily',
      sub: 'On every order!',
      icon: Icons.monetization_on,
      btnText: 'My Wallet',
      action: 'wallet',
    ),
  ];

  void _handleAction(BuildContext ctx, String action) {
    if (action.startsWith('coupon:')) {
      final code = action.split(':')[1];
      final ok = ctx.read<AppStateProvider>().applyCoupon(code);
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
        content: Text(ok ? 'Coupon $code applied! 🥳' : 'Add items to cart first'),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ));
    } else if (action == 'grocery') {
      Navigator.pushNamed(ctx, AppRoutes.grocery);
    } else if (action == 'wallet') {
      Navigator.pushNamed(ctx, AppRoutes.wallet);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          options: CarouselOptions(
            height: 160,
            viewportFraction: 0.9,
            autoPlay: true,
            autoPlayInterval: const Duration(seconds: 4),
            enlargeCenterPage: true,
            onPageChanged: (i, _) => setState(() => _current = i),
          ),
          items: _promos.map((p) => _PromoCard(
            promo: p,
            onTap: () => _handleAction(context, p.action),
          )).toList(),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            _promos.length,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: i == _current ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: i == _current
                    ? AppColors.primary
                    : AppColors.border,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _Promo {
  final List<Color> grad;
  final String badge, title, sub, btnText, action;
  final IconData icon;
  const _Promo(
      {required this.grad,
      required this.badge,
      required this.title,
      required this.sub,
      required this.icon,
      required this.btnText,
      required this.action});
}

class _PromoCard extends StatelessWidget {
  final _Promo promo;
  final VoidCallback onTap;
  const _PromoCard({required this.promo, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: promo.grad,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Stack(
        children: [
          // Background icon
          Positioned(
            right: -16,
            bottom: -16,
            child: Icon(promo.icon,
                size: 100, color: Colors.white.withOpacity(0.15)),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(promo.badge,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5)),
                ),
                const SizedBox(height: 6),
                Text(promo.title,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        height: 1.2)),
                const SizedBox(height: 4),
                Text(promo.sub,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 11)),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: onTap,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(promo.btnText,
                        style: TextStyle(
                            color: promo.grad[0],
                            fontWeight: FontWeight.bold,
                            fontSize: 12)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
