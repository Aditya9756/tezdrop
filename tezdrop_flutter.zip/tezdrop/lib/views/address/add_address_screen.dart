import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/address_model.dart';
import '../../core/services/location_service.dart';
import '../../providers/app_state_provider.dart';

class AddAddressScreen extends StatefulWidget {
  const AddAddressScreen({super.key});
  @override
  State<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  final _nameCtrl     = TextEditingController();
  final _phoneCtrl    = TextEditingController();
  final _flatCtrl     = TextEditingController();
  final _areaCtrl     = TextEditingController();
  final _landmarkCtrl = TextEditingController();

  String _addrType = 'home';
  bool   _gpsLoading  = false;
  bool   _showMiniMap = false;
  double? _gpsLat, _gpsLng;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _flatCtrl.dispose();
    _areaCtrl.dispose();
    _landmarkCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: AppColors.primary,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  Future<void> _fetchGps() async {
    setState(() => _gpsLoading = true);
    final pos = await LocationService.getCurrentPosition();
    if (pos != null) {
      final addr = await LocationService.getAddressFromCoords(
          pos.latitude, pos.longitude);
      setState(() {
        _gpsLat       = pos.latitude;
        _gpsLng       = pos.longitude;
        _areaCtrl.text = addr;
        _showMiniMap  = true;
        _gpsLoading   = false;
      });
      _snack('Location fetched! 📍');
    } else {
      setState(() => _gpsLoading = false);
      _snack('GPS denied. Enter area manually.');
    }
  }

  void _setType(String t) => setState(() => _addrType = t);

  void _save() {
    final area = _areaCtrl.text.trim();
    if (area.isEmpty) {
      _snack('Please enter area or use GPS');
      return;
    }
    final addr = AddressModel(
      type    : _addrType,
      name    : _nameCtrl.text.trim(),
      phone   : _phoneCtrl.text.trim(),
      flat    : _flatCtrl.text.trim(),
      area    : area,
      landmark: _landmarkCtrl.text.trim(),
      lat     : _gpsLat,
      lng     : _gpsLng,
    );
    context.read<AppStateProvider>().addAddress(addr);
    _snack('Address saved! 🏠');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add New Address')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // GPS button
          GestureDetector(
            onTap: _gpsLoading ? null : _fetchGps,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF0FDF4),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFBBF7D0)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_gpsLoading)
                    const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppColors.green))
                  else
                    const Icon(Icons.gps_fixed,
                        color: AppColors.green, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    _gpsLoading
                        ? 'Fetching location...'
                        : _showMiniMap
                            ? 'Location Fetched ✓'
                            : 'Use Current Location (Live GPS)',
                    style: const TextStyle(
                        color: AppColors.green,
                        fontWeight: FontWeight.bold,
                        fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Mini map preview
          if (_showMiniMap && _gpsLat != null && _gpsLng != null)
            Container(
              height: 150,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.green, width: 2),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Stack(
                  children: [
                    FlutterMap(
                      options: MapOptions(
                        initialCenter: LatLng(_gpsLat!, _gpsLng!),
                        initialZoom: 15,
                        interactionOptions: const InteractionOptions(
                          flags: InteractiveFlag.none,
                        ),
                      ),
                      children: [
                        TileLayer(
                          urlTemplate:
                              'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
                          subdomains: const ['mt0', 'mt1', 'mt2', 'mt3'],
                          userAgentPackageName: 'com.tezdrop.app',
                        ),
                        MarkerLayer(markers: [
                          Marker(
                            point: LatLng(_gpsLat!, _gpsLng!),
                            width: 40,
                            height: 40,
                            child: const Icon(Icons.location_on,
                                color: AppColors.primary, size: 36),
                          ),
                        ]),
                      ],
                    ),
                    Positioned(
                      bottom: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.green,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle),
                            ),
                            const SizedBox(width: 4),
                            const Text('Live Location',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Form fields
          _Field(ctrl: _nameCtrl, hint: 'Full Name'),
          const SizedBox(height: 12),
          _Field(
              ctrl: _phoneCtrl,
              hint: 'Phone Number',
              type: TextInputType.phone),
          const SizedBox(height: 12),
          _Field(ctrl: _flatCtrl, hint: 'Flat, House No, Building'),
          const SizedBox(height: 12),
          _Field(
              ctrl: _areaCtrl,
              hint: 'Area, Sector, Locality (auto-fills with GPS)',
              maxLines: 2),
          const SizedBox(height: 12),
          _Field(ctrl: _landmarkCtrl, hint: 'Landmark (optional)'),
          const SizedBox(height: 16),

          // Address type selector
          Row(
            children: [
              _TypeBtn('🏠 Home', 'home', _addrType, _setType),
              const SizedBox(width: 8),
              _TypeBtn('💼 Work', 'work', _addrType, _setType),
              const SizedBox(width: 8),
              _TypeBtn('📍 Other', 'other', _addrType, _setType),
            ],
          ),
          const SizedBox(height: 24),

          // Save button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _save,
              child: const Text('Save Address'),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final TextInputType type;
  final int maxLines;
  const _Field(
      {required this.ctrl,
      required this.hint,
      this.type = TextInputType.text,
      this.maxLines = 1});
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: ctrl,
      keyboardType: type,
      maxLines: maxLines,
      decoration: InputDecoration(hintText: hint),
    );
  }
}

class _TypeBtn extends StatelessWidget {
  final String label, key, current;
  final void Function(String) onTap;
  const _TypeBtn(this.label, this.key, this.current, this.onTap);
  @override
  Widget build(BuildContext context) {
    final active = current == key;
    return Expanded(
      child: GestureDetector(
        onTap: () => onTap(key),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active
                ? const Color(0xFFFEE2E2)
                : Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: active ? AppColors.primary : AppColors.border,
              width: active ? 2 : 1,
            ),
          ),
          child: Text(label,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color:
                      active ? AppColors.primary : AppColors.textGrey)),
        ),
      ),
    );
  }
}
