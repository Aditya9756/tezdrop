import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/product_model.dart';
import '../../core/routes/app_routes.dart';
import '../../providers/app_state_provider.dart';

class ProductDetailScreen extends StatefulWidget {
  final String productId;
  final bool isGrocery;
  const ProductDetailScreen(
      {super.key, required this.productId, required this.isGrocery});
  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _qty = 1;
  bool _extraCheese = false;

  static const _reviews = [
    {'name': 'Rahul K.', 'stars': 5, 'text': 'Absolutely delicious! Delivered hot and fresh.'},
    {'name': 'Priya S.', 'stars': 4, 'text': 'Good taste, packaging could be better.'},
    {'name': 'Amit T.',  'stars': 5, 'text': 'Best in the area! Will order again.'},
  ];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppStateProvider>();
    final src   = widget.isGrocery ? state.groceryItems : state.products;
    final p     = src.firstWhere((x) => x.id == widget.productId,
        orElse: () => src.first);

    final cheeseExtra = (!widget.isGrocery && _extraCheese) ? 30.0 : 0.0;
    final lineTotal   = (p.price + cheeseExtra) * _qty;
    final inWish      = state.isWishlisted(p.id);

    final related = src
        .where((x) => x.category == p.category && x.id != p.id && !x.isOutOfStock)
        .take(3)
        .toList();

    return Scaffold(
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              // Hero image
              SliverAppBar(
                expandedHeight: 280,
                pinned: true,
                backgroundColor: const Color(0xFFF3F4F6),
                leading: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.arrow_back, color: Colors.black),
                  ),
                ),
                actions: [
                  GestureDetector(
                    onTap: () => state.toggleWish(p.id),
                    child: Container(
                      margin: const EdgeInsets.all(8),
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        inWish ? Icons.favorite : Icons.favorite_border,
                        color: inWish ? AppColors.primary : Colors.black,
                        size: 18,
                      ),
                    ),
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    color: const Color(0xFFF3F4F6),
                    child: Center(
                      child: Text(p.image,
                          style: const TextStyle(fontSize: 100)),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Container(
                  color: Theme.of(context).colorScheme.surface,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(28)),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Veg dot + category
                          Row(
                            children: [
                              Container(
                                width: 16,
                                height: 16,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color: p.type == 'veg'
                                          ? AppColors.green
                                          : AppColors.primary,
                                      width: 1.5),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Center(
                                  child: Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: p.type == 'veg'
                                          ? AppColors.green
                                          : AppColors.primary,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(p.category.toUpperCase(),
                                  style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textGrey,
                                      letterSpacing: 0.5)),
                              const Spacer(),
                              if (widget.isGrocery && p.unit != null)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFDCFCE7),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(p.unit!,
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.green,
                                          fontWeight: FontWeight.bold)),
                                ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFDCFCE7),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.star,
                                        color: AppColors.green, size: 12),
                                    const SizedBox(width: 3),
                                    Text('${p.rating}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            color: AppColors.green)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          // Name
                          Text(p.name,
                              style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          // Desc
                          Text(p.desc.isNotEmpty
                              ? p.desc
                              : 'Freshly prepared with quality ingredients.',
                              style: const TextStyle(
                                  color: AppColors.textGrey,
                                  fontSize: 13,
                                  height: 1.5)),
                          const SizedBox(height: 12),
                          // Price
                          Row(
                            children: [
                              Text('₹${p.price.toInt()}',
                                  style: const TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.primary)),
                              const SizedBox(width: 10),
                              Text('₹${p.oldPrice.toInt()}',
                                  style: const TextStyle(
                                      fontSize: 14,
                                      color: AppColors.textLight,
                                      decoration: TextDecoration.lineThrough)),
                              const SizedBox(width: 8),
                              if (p.discountPercent > 0)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFDCFCE7),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text('${p.discountPercent}% OFF',
                                      style: const TextStyle(
                                          color: AppColors.green,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 11)),
                                ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          // Stock info
                          _StockBanner(product: p),
                          const SizedBox(height: 16),
                          // Add-ons (food only)
                          if (!widget.isGrocery) ...[
                            const Text('Add-ons',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15)),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF9FAFB),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppColors.border),
                              ),
                              child: Row(
                                children: [
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text('Extra Cheese',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600)),
                                        Text('Makes it tastier!',
                                            style: TextStyle(
                                                color: AppColors.textGrey,
                                                fontSize: 12)),
                                      ],
                                    ),
                                  ),
                                  const Text('+₹30',
                                      style: TextStyle(
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.bold)),
                                  const SizedBox(width: 10),
                                  Switch(
                                    value: _extraCheese,
                                    activeColor: AppColors.primary,
                                    onChanged: (v) =>
                                        setState(() => _extraCheese = v),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                          ],
                          // Reviews
                          const Text('Customer Reviews',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 15)),
                          const SizedBox(height: 10),
                          ..._reviews.map((r) => Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF9FAFB),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(r['name'] as String,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13)),
                                        Row(
                                          children: List.generate(
                                              5,
                                              (i) => Icon(Icons.star,
                                                  size: 12,
                                                  color: i < (r['stars'] as int)
                                                      ? AppColors.yellow
                                                      : AppColors.border)),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(r['text'] as String,
                                        style: const TextStyle(
                                            color: AppColors.textGrey,
                                            fontSize: 12)),
                                  ],
                                ),
                              )),
                          // Frequently bought together
                          if (related.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            const Text('🛒 Frequently Bought Together',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15)),
                            const SizedBox(height: 10),
                            ...related.map((r) => GestureDetector(
                                  onTap: () => Navigator.pushNamed(
                                    context,
                                    AppRoutes.product,
                                    arguments: {
                                      'productId': r.id,
                                      'isGrocery': r.isGrocery,
                                    },
                                  ),
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 8),
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF9FAFB),
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      border: Border.all(
                                          color: AppColors.border),
                                    ),
                                    child: Row(
                                      children: [
                                        Text(r.image,
                                            style: const TextStyle(
                                                fontSize: 28)),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(r.name,
                                                  style: const TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 12),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis),
                                              Text('₹${r.price.toInt()}',
                                                  style: const TextStyle(
                                                      color: AppColors.primary,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 12)),
                                            ],
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () => state.addToCart(r),
                                          child: Container(
                                            width: 28,
                                            height: 28,
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFEE2E2),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            child: const Icon(Icons.add,
                                                color: AppColors.primary,
                                                size: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )),
                          ],
                          const SizedBox(height: 100),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          // Bottom bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                border: Border(
                    top: BorderSide(color: AppColors.border)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 12,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  // Qty selector
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.border),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        _QtyBtn(
                          icon: Icons.remove,
                          onTap: () {
                            if (_qty > 1) setState(() => _qty--);
                          },
                        ),
                        Padding(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 14),
                          child: Text('$_qty',
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16)),
                        ),
                        _QtyBtn(
                          icon: Icons.add,
                          onTap: () {
                            if (_qty < 10) setState(() => _qty++);
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Add to cart
                  Expanded(
                    child: GestureDetector(
                      onTap: p.isOutOfStock
                          ? null
                          : () {
                              for (int i = 0; i < _qty; i++) {
                                state.addToCart(p);
                              }
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                content: Text(
                                    '${p.name} added to cart! 🛒'),
                                backgroundColor: AppColors.primary,
                                behavior: SnackBarBehavior.floating,
                                shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(12)),
                              ));
                            },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          gradient: p.isOutOfStock
                              ? null
                              : AppColors.brandGradient,
                          color: p.isOutOfStock
                              ? const Color(0xFFE5E7EB)
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: p.isOutOfStock
                              ? []
                              : [
                                  BoxShadow(
                                    color: AppColors.primary
                                        .withOpacity(0.3),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  )
                                ],
                        ),
                        child: Row(
                          mainAxisAlignment:
                              MainAxisAlignment.center,
                          children: [
                            Text(
                              p.isOutOfStock
                                  ? 'Out of Stock'
                                  : 'Add to Cart',
                              style: TextStyle(
                                  color: p.isOutOfStock
                                      ? AppColors.textGrey
                                      : Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15),
                            ),
                            if (!p.isOutOfStock) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius:
                                      BorderRadius.circular(8),
                                ),
                                child: Text(
                                  '₹${lineTotal.toInt()}',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 48,
        decoration: BoxDecoration(
          color: const Color(0xFFFEE2E2),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: AppColors.primary, size: 18),
      ),
    );
  }
}

class _StockBanner extends StatelessWidget {
  final ProductModel product;
  const _StockBanner({required this.product});
  @override
  Widget build(BuildContext context) {
    if (product.isOutOfStock) {
      return _Banner(
          icon: Icons.cancel_outlined,
          text: 'Out of Stock — Currently unavailable',
          color: const Color(0xFFFEE2E2),
          iconColor: AppColors.primary);
    }
    if (product.isLowStock) {
      return _Banner(
          icon: Icons.warning_amber_outlined,
          text: 'Only ${product.stock} left! Order fast 🔥',
          color: const Color(0xFFFFF7ED),
          iconColor: AppColors.secondary);
    }
    return _Banner(
        icon: Icons.check_circle_outline,
        text: 'In Stock ✅ Delivery in 20-30 mins',
        color: const Color(0xFFF0FDF4),
        iconColor: AppColors.green);
  }
}

class _Banner extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color, iconColor;
  const _Banner(
      {required this.icon,
      required this.text,
      required this.color,
      required this.iconColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text,
                style: TextStyle(
                    color: iconColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 12)),
          ),
        ],
      ),
    );
  }
}
