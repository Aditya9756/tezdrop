import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/constants/app_colors.dart';
import '../../core/services/location_service.dart';
import '../../core/services/routing_service.dart';
import '../../core/services/firebase_service.dart';
import '../../providers/app_state_provider.dart';

class OrderTrackingScreen extends StatefulWidget {
  final String orderId, riderName, riderPhone;
  const OrderTrackingScreen({
    super.key,
    required this.orderId,
    required this.riderName,
    required this.riderPhone,
  });
  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  // Map
  final MapController _mapCtrl = MapController();
  LatLng _userPos   = const LatLng(28.6139, 77.2090);
  LatLng _riderPos  = const LatLng(28.6220, 77.2180);
  List<LatLng> _routePoints = [];
  List<LatLng> _remainingRoute = [];

  // Timer
  int _secs = 15 * 60;
  Timer? _timerIv;

  // Bike animation
  int    _bikeIdx   = 0;
  Timer? _bikeTimer;
  double _bikeBearing = 180;

  // Tracking
  Timer?  _pollTimer;
  String  _riderName = '';
  String  _riderPhone = '';
  String  _gpsInfo    = 'Connecting to rider location...';

  // Micro steps
  final List<_Step> _steps = [
    _Step('Placed',   Icons.check,      true,  false),
    _Step('Preparing',Icons.local_fire_department, false, true),
    _Step('Packed',   Icons.inventory_2,false, false),
    _Step('On Way',   Icons.motorcycle, false, false),
    _Step('Delivered',Icons.home,       false, false),
  ];
  int _stepTimer = 0;

  @override
  void initState() {
    super.initState();
    _riderName  = widget.riderName;
    _riderPhone = widget.riderPhone;
    _loadTracking();
    _startTimer();
    _startStepAdvance();
  }

  @override
  void dispose() {
    _timerIv?.cancel();
    _bikeTimer?.cancel();
    _pollTimer?.cancel();
    super.dispose();
  }

  // ── Timer ─────────────────────────────────────────────
  void _startTimer() {
    _timerIv = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_secs > 0) {
        setState(() => _secs--);
      } else {
        _timerIv?.cancel();
        setState(() {});
      }
    });
  }

  String get _timerLabel {
    if (_secs <= 0) return 'Arrived! 🎉';
    final m = (_secs ~/ 60).toString().padLeft(2, '0');
    final s = (_secs % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ── Micro step advance ────────────────────────────────
  void _startStepAdvance() {
    final delays = [60, 120, 180, 240];
    for (int i = 0; i < delays.length; i++) {
      Future.delayed(Duration(seconds: delays[i]), () {
        if (!mounted) return;
        setState(() {
          _steps[i].done   = true;
          _steps[i].active = false;
          if (i + 1 < _steps.length) _steps[i + 1].active = true;
        });
        if (i == 3) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Order Delivered! 🎉 Rate your experience ⭐'),
            backgroundColor: AppColors.green,
            behavior: SnackBarBehavior.floating,
          ));
        }
      });
    }
  }

  // ── Load map + route ──────────────────────────────────
  Future<void> _loadTracking() async {
    // Get user GPS
    final pos = await LocationService.getCurrentPosition();
    if (pos != null) {
      setState(() {
        _userPos = LatLng(pos.latitude, pos.longitude);
        _riderPos = LatLng(
          pos.latitude  + 0.008 + 0.004,
          pos.longitude + 0.006 + 0.002,
        );
      });
    }

    setState(() => _gpsInfo = 'Road path calculate ho raha hai... 🗺️');

    // Get OSRM road path
    final path = await RoutingService.getRoadPath(
      fromLat: _riderPos.latitude,
      fromLng: _riderPos.longitude,
      toLat  : _userPos.latitude,
      toLng  : _userPos.longitude,
    );

    if (!mounted) return;
    setState(() {
      _routePoints    = path;
      _remainingRoute = List.from(path);
      _gpsInfo =
          'Road path ready — ${path.length} points 🛣️';
    });

    // Start bike animation
    _startBikeAnimation();

    // Poll Firebase for real rider location
    _pollRiderLocation();

    // Fetch rider name from Firebase
    _fetchRiderFromFirebase();
  }

  void _startBikeAnimation() {
    if (_routePoints.length < 2) return;
    _bikeIdx = 0;
    final totalMs = 25000;
    final stepMs  = (totalMs / _routePoints.length).round().clamp(100, 2000);

    _bikeTimer?.cancel();
    _bikeTimer = Timer.periodic(Duration(milliseconds: stepMs), (_) {
      if (!mounted || _bikeIdx >= _routePoints.length - 1) {
        _bikeTimer?.cancel();
        return;
      }
      setState(() {
        _bikeIdx++;
        _riderPos = _routePoints[_bikeIdx];
        if (_bikeIdx > 0) {
          _bikeBearing = RoutingService.getBearing(
            _routePoints[_bikeIdx - 1],
            _routePoints[_bikeIdx],
          );
        }
        _remainingRoute = _routePoints.sublist(_bikeIdx);
      });
    });
  }

  void _pollRiderLocation() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final data =
          await FirebaseService.getRiderLocation(widget.orderId);
      if (data == null || !mounted) return;
      final lat = (data['lat'] as num?)?.toDouble();
      final lng = (data['lng'] as num?)?.toDouble();
      if (lat != null && lng != null) {
        final newPos = LatLng(lat, lng);
        final bearing =
            RoutingService.getBearing(_riderPos, newPos);
        setState(() {
          _riderPos    = newPos;
          _bikeBearing = bearing;
          _gpsInfo =
              '🛵 Rider live location: ${lat.toStringAsFixed(4)}, ${lng.toStringAsFixed(4)}';
        });
      }
    });
  }

  Future<void> _fetchRiderFromFirebase() async {
    final order =
        await FirebaseService.getOrderById(widget.orderId);
    if (order == null || !mounted) return;
    if (order.rider.isNotEmpty) {
      setState(() {
        _riderName  = order.rider;
        _riderPhone = order.riderPhone;
      });
    }
  }

  Future<void> _callRider() async {
    if (_riderPhone.isEmpty) return;
    final uri = Uri.parse('tel:$_riderPhone');
    if (await canLaunchUrl(uri)) launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // ── Map (top 40%) ─────────────────────────────
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.40,
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapCtrl,
                  options: MapOptions(
                    initialCenter: LatLng(
                      (_userPos.latitude + _riderPos.latitude) / 2,
                      (_userPos.longitude + _riderPos.longitude) / 2,
                    ),
                    initialZoom: 14,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
                      subdomains: const [
                        'mt0', 'mt1', 'mt2', 'mt3'
                      ],
                      userAgentPackageName: 'com.tezdrop.app',
                    ),
                    // Route polyline
                    if (_remainingRoute.length > 1)
                      PolylineLayer(polylines: [
                        Polyline(
                          points: _remainingRoute,
                          color: AppColors.primary,
                          strokeWidth: 4,
                          pattern: const StrokePattern.dashed(
                              segments: [10, 6]),
                        ),
                      ]),
                    // Markers
                    MarkerLayer(markers: [
                      // Customer pin
                      Marker(
                        point: _userPos,
                        width: 40,
                        height: 40,
                        child: const Icon(Icons.location_on,
                            color: AppColors.primary, size: 36),
                      ),
                      // Bike marker (rotated)
                      Marker(
                        point: _riderPos,
                        width: 40,
                        height: 40,
                        child: Transform.rotate(
                          angle: _bikeBearing * 3.14159265 / 180,
                          child: const Text('🛵',
                              style: TextStyle(fontSize: 28)),
                        ),
                      ),
                    ]),
                  ],
                ),
                // Back button
                Positioned(
                  top: MediaQuery.of(context).padding.top + 8,
                  left: 12,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.arrow_back, size: 20),
                    ),
                  ),
                ),
                // LIVE badge
                Positioned(
                  top: MediaQuery.of(context).padding.top + 8,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.green,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 5),
                        const Text('LIVE',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Bottom panel ──────────────────────────────
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(28)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 16,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  // Timer + order ID
                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text('Arriving in ',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold)),
                              Text(_timerLabel,
                                  style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.primary)),
                            ],
                          ),
                          Text('Order #${widget.orderId}',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textGrey)),
                        ],
                      ),
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0FDF4),
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: const Color(0xFFBBF7D0),
                              width: 2),
                        ),
                        child: const Icon(Icons.motorcycle,
                            color: AppColors.green, size: 22),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Micro steps
                  Row(
                    children: _steps.asMap().entries.map((e) {
                      final i = e.key;
                      final s = e.value;
                      return Expanded(
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Container(
                                    width: 32,
                                    height: 32,
                                    decoration: BoxDecoration(
                                      color: s.done
                                          ? AppColors.green
                                          : s.active
                                              ? AppColors.primary
                                              : AppColors.border,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(s.icon,
                                        color: (s.done || s.active)
                                            ? Colors.white
                                            : AppColors.textLight,
                                        size: 14),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(s.label,
                                      style: TextStyle(
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                          color: s.done
                                              ? AppColors.green
                                              : s.active
                                                  ? AppColors.primary
                                                  : AppColors.textLight),
                                      textAlign: TextAlign.center),
                                ],
                              ),
                            ),
                            if (i < _steps.length - 1)
                              Expanded(
                                child: Container(
                                  height: 2,
                                  margin: const EdgeInsets.only(
                                      bottom: 20),
                                  color: _steps[i].done
                                      ? AppColors.green
                                      : AppColors.border,
                                ),
                              ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),

                  // GPS info
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEFF6FF),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: const Color(0xFFBFDBFE)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on,
                            color: AppColors.blue, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(_gpsInfo,
                              style: const TextStyle(
                                  color: AppColors.blue,
                                  fontSize: 11)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Rider card
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF9FAFB),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: AppColors.border,
                            shape: BoxShape.circle,
                          ),
                          child: const Center(
                            child: Text('🧑',
                                style: TextStyle(fontSize: 24)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(
                                _riderName.isEmpty
                                    ? 'Assigning rider...'
                                    : _riderName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14),
                              ),
                              const Row(
                                children: [
                                  Icon(Icons.star,
                                      color: AppColors.yellow,
                                      size: 12),
                                  SizedBox(width: 3),
                                  Text('4.8 Rating',
                                      style: TextStyle(
                                          fontSize: 11,
                                          color: AppColors.textGrey)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: _callRider,
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFFF0FDF4),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.phone,
                                color: AppColors.green, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Step {
  final String label;
  final IconData icon;
  bool done, active;
  _Step(this.label, this.icon, this.done, this.active);
}
