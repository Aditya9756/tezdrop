import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/app_state_provider.dart';

class InvoiceScreen extends StatelessWidget {
  final String orderId;
  const InvoiceScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    final orders = context.read<AppStateProvider>().orders;
    final order  = orders.firstWhere(
      (o) => o.orderId == orderId,
      orElse: () => orders.first,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Order Invoice')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) =>
                              AppColors.brandGradient.createShader(bounds),
                          child: const Text('TezDrop',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white)),
                        ),
                        const Text('⚡ Food & Grocery Delivery',
                            style: TextStyle(
                                color: AppColors.textGrey,
                                fontSize: 11)),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('INVOICE',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                                color: AppColors.textGrey,
                                letterSpacing: 1)),
                        Text('#${order.orderId}',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary)),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 24),
                // Details
                _Row('Date', order.timestamp),
                const SizedBox(height: 6),
                _Row('Address', order.address),
                const SizedBox(height: 6),
                _Row('Payment', order.payment,
                    valueColor: AppColors.green),
                const Divider(height: 24),
                // Items table
                Row(
                  children: const [
                    Expanded(
                        child: Text('Item',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: AppColors.textGrey))),
                    SizedBox(
                        width: 40,
                        child: Text('Qty',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: AppColors.textGrey))),
                    SizedBox(
                        width: 70,
                        child: Text('Amount',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: AppColors.textGrey))),
                  ],
                ),
                const SizedBox(height: 10),
                ...order.items.map((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${item.name}${item.isGrocery ? " 🛒" : ""}',
                              style: const TextStyle(fontSize: 13),
                            ),
                          ),
                          SizedBox(
                            width: 40,
                            child: Text('×${item.qty}',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: AppColors.textGrey,
                                    fontSize: 13)),
                          ),
                          SizedBox(
                            width: 70,
                            child: Text(
                              '₹${(item.price * item.qty).toInt()}',
                              textAlign: TextAlign.right,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    )),
                const Divider(height: 20),
                // Total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Paid',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    Text('₹${order.total.toInt()}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 18,
                            color: AppColors.primary)),
                  ],
                ),
                const SizedBox(height: 20),
                Center(
                  child: Text(
                    'Thank you for ordering from TezDrop! ⚡',
                    style: TextStyle(
                        color: AppColors.textGrey, fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label, value;
  final Color? valueColor;
  const _Row(this.label, this.value, {this.valueColor});
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(label,
              style: const TextStyle(
                  color: AppColors.textGrey, fontSize: 12)),
        ),
        Expanded(
          child: Text(value,
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                  color: valueColor)),
        ),
      ],
    );
  }
}
