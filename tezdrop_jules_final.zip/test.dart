void main() {
  List<double> prices = [10.0, 20.0];
  var total = prices.fold(0, (s, i) => s + i);
  print(total);
}
